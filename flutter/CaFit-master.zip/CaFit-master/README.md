<p><strong>CaFit Home Workout app with Flutter:</strong></p>
<p>&nbsp;</p>
<ul>
<li>App built with Flutter using provider architecture for state management with MVVM.</li>
</ul>

<p>&nbsp;</p>
<p><strong>Steps to use the Code:</strong></p>
<p>1 &ndash; Star ⭐ and clone the repo.</p>
<p>2 &ndash; Download the source code.</p>
<p>3 &ndash; Extract the code and open it with VSCode or Android studio.</p>
<p>4 - Get all the packages and run the app.</p>
<p>For projects, contact me at my email account: <strong>musabapps2019@gmail.com</strong></p>


<p><strong>App Screenshots:</strong>&nbsp;</p>

![](Screenshots/Screenshot_1594717551_pixel_quite_black_portrait.png)
![](Screenshots/Screenshot_1594717559_pixel_quite_black_portrait.png)
![](Screenshots/Screenshot_1594717567_pixel_quite_black_portrait.png)
![](Screenshots/Screenshot_1594717573_pixel_quite_black_portrait.png)

