const String FULL_BODY = "Full body workout";
const String LEG_WORKOUT = "Leg workout";
const String ARM_WORKOUT = "Arm workout";

const String EXERCISE_DURAION = "30 s";
