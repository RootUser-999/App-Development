class Exercise {
  String name;
  String duration;
  String assetPath;
  String description;
  String youtubeURL;

  Exercise(this.name, this.duration, this.assetPath, this.description,
      this.youtubeURL);
}
