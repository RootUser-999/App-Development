class WorkoutCategory {
  String name;
  String desc;
  String photoUrl;
  WorkoutCategory(this.name, this.desc, this.photoUrl);
}
