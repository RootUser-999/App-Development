import 'package:flutter/material.dart';

const Color backgroundColor = Color(0xFFFFFFFF);
const Color primaryColor = Color(0xFFFF9B70);
const Color primaryColorDark = Color(0xFFC05122);
const Color primaryLight = Color(0xFFFFB595);
